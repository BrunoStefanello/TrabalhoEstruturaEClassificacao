/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho2bimordenacao;
import javax.swing.JOptionPane;
/**
 *
 * @author Bruno Stefanello
 */
public class Trabalho2BimOrdenacao {

    
       public static void main(String[] args) {
        Vetor vetorBolha = new OrdenacaoBolha();
        Vetor vetorInsercao = new OrdenacaoInsercao();
        Vetor vetorSelecao = new OrdenacaoSelecao();
       
        int opcao = -1;
        int vetor[];
        while(opcao != 0 ){
            opcao = Integer.parseInt(JOptionPane.showInputDialog("""
                                                                 Como voc\u00ea gostaria de ordenar o vetor? 
                                                                  1 - Ordena\u00e7\u00e3o por BubbleSort
                                                                 2 - Ordena\u00e7\u00e3o por Inser\u00e7\u00e3o 
                                                                 3 - Ordena\u00e7\u00e3o por Sele\u00e7\u00e3o 
                                                                 0 - Sair"""));
                             
            switch (opcao) {
                case 1 -> vetorBolha.vetores();
                case 2 -> vetorInsercao.vetores();
                case 3 -> vetorSelecao.vetores();
                default -> {
                }
            }
        }
    }
}